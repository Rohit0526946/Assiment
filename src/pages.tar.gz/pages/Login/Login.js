import React, { Component } from 'react';
import { connect } from 'react-redux';
import { userActions } from '../../_actions';
import {
  View, Text, Dimensions,
  TouchableOpacity, ImageBackground, TextInput, Image
} from 'react-native';

const { height, width } = Dimensions.get('window')
class Login extends Component {
  constructor(props) {
    super(props);
    this.props.dispatch(userActions.logout());
    this.state = {
      email: '',
      otp_code: '',
      showLogin: true,
      failureMSG: '',
      failureOTPMSG: '',
      time: {},
      seconds: 120
    },
      this.timer = 0;
    this.startTimer = this.startTimer.bind(this);
    this.countDown = this.countDown.bind(this);
  }
  static getDerivedStateFromProps(nextProps, prevState) {

    if (nextProps.users.UserLoginFailure) {
      return {
        ...nextProps,
        failureMSG: 'Please enter valid username!'

      }
    }
    if (nextProps.users.UserLoginOTPFailure) {
      return {
        ...nextProps,
        failureOTPMSG: 'Invalid OTP or expired!'

      }
    }
    if (nextProps.users.UserLoginEmailSuccess) {
      return {
        ...nextProps,
        showLogin: false

      }
    }
    else {
      return {
        ...nextProps
      }
    }

  }

  secondsToTime(secs) {
    let hours = Math.floor(secs / (60 * 60));

    let divisor_for_minutes = secs % (60 * 60);
    let minutes = Math.floor(divisor_for_minutes / 60);

    let divisor_for_seconds = divisor_for_minutes % 60;
    let seconds = Math.ceil(divisor_for_seconds);

    let obj = {
      "h": hours,
      "m": minutes,
      "s": seconds
    };
    return obj;
  }
  startTimer() {
    if (this.timer == 0 && this.state.seconds > 0) {
      this.timer = setInterval(this.countDown, 1000);
    }
  }

  countDown() {
    let seconds = this.state.seconds - 1;
    this.setState({
      time: this.secondsToTime(seconds),
      seconds: seconds,
    });

    if (seconds == 0) {
      clearInterval(this.timer);
    }
  }
  async componentDidMount() {

  }
  handleLoginInput = (text) => {
    this.setState({ email: text })
  }
  handleLoginInputPassword = (text) => {
    this.setState({ password: text })
  }

  submitLogin = () => {

    let data = {
      email: this.state.email,
      password: this.state.password,
    }
    this.props.dispatch(userActions.userlogin(data, this.props));
    this.startTimer()
  }

  onSubmitOTP = () => {
    const { users } = this.props;
    const { UserEmailToken } = users;
    if (this.state.otp !== 'NaN') {
      let data = {
        email: this.state.email,
        password: this.state.password,
        otp: this.state.otp
      }

      this.props.dispatch(userActions.validateOtp(data, this.props));
    }
  }



  handleVerificationInput = (text) => {
    this.setState({ otp: text })
  }

  gotoIntroScreen = (router) => {
    this.props.navigation.navigate(router)
  }

  render() {
    let { email, password } = this.state;

    return (
      <View style={{ flex: 1, backgroundColor: '#233446', borderWidth: 1, borderColor: '#2DA4FE' }}>
        <View style={{ flex: 1, borderWidth: 1, borderColor: '#2DA4FE' }} >

          <View style={{ justifyContent: 'space-around' }}>
             <View style={{ marginTop: 30, height: 50, width: width, flexDirection: 'row', alignItems: 'center' }}>

                            <View style={{ height: '100%', width: 20, backgroundColor: '#2DA4FE', borderTopRightRadius: 6, borderBottomRightRadius: 6 }} />
                            <Text style={{ fontSize: 30, color: '#2DA4FE', textShadowOffset: { width: 1, height: 1 },  }}> SIGN IN </Text>
                        </View> 

{/* 
            <View style={{ marginTop: 30, height: 80, width: width, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>

              <Image style={{ height: 75, width: 75, alignSelf: 'center' }} source={require('../../Statics/img/Wallet/logo1.png')} />
              <Text style={{ fontSize: 40, color: 'white', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 1, textShadowColor: 'white' }}>
                <Text style={{ fontSize: 40, color: '#C79323', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 1, textShadowColor: 'white' }}> Coin  </Text> </Text>
            </View> */}

          </View>


          
                    <ImageBackground style={{ flex: 1, width: width - 12, marginTop: height / 2 - 150 }} source={require('../../Statics/img/Login/Rectangle2.png')}
                        imageStyle={{
                            resizeMode: 'cover' // works only here!
                        }}>

                    </ImageBackground> 

          <View style={{ alignItems: 'center', position: 'absolute', marginTop: height / 2 - 200, marginHorizontal: 19 }}>


            {this.state.showLogin ?
              <>
                <View style={{ justifyContent: 'space-between', height: height - (height / 2 - 200), paddingBottom: 10 }}>
                  <View style={{ backgroundColor: '#18222C', width: width - 50, borderRadius: 10, elevation: 8,  }}>
                    <View style={{ borderRadius: 10, borderWidth:1, borderColor: '#2DA4FE' }}>

                      <View style={{ marginHorizontal: 20, height: 45, backgroundColor: '#F6F6F6', marginTop: 30, borderRadius: 10 }}>
                        <TextInput
                          style={{ marginHorizontal: 10, fontSize: 15 }}
                          placeholder="Email"
                          name="email"
                          onChangeText={(text) => this.handleLoginInput(text)}
                          value={email}
                        />
                      </View>

                      <View style={{ marginHorizontal: 20, height: 45, backgroundColor: '#F6F6F6', marginTop: 20, borderRadius: 10 }}>
                        <TextInput
                          style={{ marginHorizontal: 10, fontSize: 15 }}
                          placeholder="Password"
                          name="password"
                          secureTextEntry={true}
                          onChangeText={(text) => this.handleLoginInputPassword(text)}
                          value={password} />
                      </View>
                      <TouchableOpacity
                        onPress={() => this.gotoIntroScreen('Forgot')}
                        style={{ marginTop: 20, alignSelf: 'flex-end', marginRight: 20 }} >
                        <Text style={{ fontSize: 15, color: '#2DA4FE', fontWeight: 'normal' }}> Forgot Password? </Text>
                      </TouchableOpacity>

                      <View style={{ borderWidth: 1, borderColor: '#2DA4FE', borderRadius: 11, marginHorizontal: 20, marginBottom: 30, marginTop: 60, elevation: 8 }}>
                        <View
                          style={{ backgroundColor: '#2DA4FE', height: 40, borderRadius: 5, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#2DA4FE' }}>

                          <TouchableOpacity style={{ width: '100%' }}
                            onPress={() => this.submitLogin()}>
                            <Text style={{ fontSize: 19, color: 'white', textAlign: 'center', textShadowOffset: { width: 1, height: 1 },  }}> LOGIN </Text>

                          </TouchableOpacity>
                        </View>

                      </View>
                    </View>
                  </View>
                  <TouchableOpacity style={{ height: 35, flexDirection: 'row', justifyContent: 'center' }}
                    onPress={() => this.gotoIntroScreen('Register')} >
                    <Text style={{ fontSize: 18, textAlign: 'center', color: 'white', textShadowOffset: { width: 1, height: 1 },  }}> Create Account, </Text>
                    <Text style={{ fontSize: 18, textAlign: 'center', color: 'black', textShadowOffset: { width: 1, height: 1 },  }}>Sign Up? </Text>
                  </TouchableOpacity>

                </View>

              </>
              :

              <View style={{ backgroundColor: '#18222C', width: width - 50, borderRadius: 25, elevation: 8, borderWidth: 1, borderColor: '#2DA4FE' }}>
                <View style={{ borderRadius: 25,  }}>

                  <Text style={{ padding: 19, color: 'white', fontSize: 22, fontWeight: 'bold', textShadowOffset: { width: 1, height: 1 },  }}>Verification</Text>
                  <Text style={{ paddingLeft: 20, fontSize: 14, color: 'white', fontWeight: 'bold', textShadowOffset: { width: 1, height: 1 },  }}>
                    OTP sent to <Text style={{ fontWeight: 'bold' }}>{email}</Text>
                  </Text>


                  <View style={{ marginHorizontal: 20, height: 45, backgroundColor: '#F6F6F6', marginTop: 20, borderRadius: 10 }}>
                    <TextInput
                      style={{ marginHorizontal: 10, fontSize: 15 }}
                      placeholder="Enter OTP"
                      name="otp"
                      onChangeText={(text) => this.handleVerificationInput(text)}
                      value={this.state.otp} />
                  </View>


                  <Text style={{
                    fontSize: 14,
                    fontWeight: 'bold',
                    marginTop: 15,
                    textAlign: 'center',
                    color: '#2DA4FE', textShadowOffset: { width: 1, height: 1 }, 
                  }}>Expire in: {this.state.time.m} : {this.state.time.s}</Text>

                  <View style={{ borderWidth: 1, borderColor: '#2DA4FE', borderRadius: 5, marginHorizontal: 20, marginBottom: 30, marginTop: 50, elevation: 8 }}>
                    <View
                      style={{ backgroundColor: '#2DA4FE', height: 40, borderRadius: 5, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#2DA4FE' }}>
                      <TouchableOpacity style={{ width: '100%' }}
                        onPress={() => this.onSubmitOTP()}
                      >


                        <Text style={{
                          textAlign: 'center',
                          color: '#fff',
                          fontWeight: 'bold',
                          fontSize: 15, textShadowOffset: { width: 1, height: 1 }, 

                        }}>VERIFY AND PROCEED</Text>
                      </TouchableOpacity>
                    </View>

                  </View>

                </View>
              </View>

            }
          </View>
        </View>
      </View>
    )
  }
}
function mapStateToProps(state) {
  const { loggingIn } = state.authentication;
  const { users } = state;
  return {
    loggingIn,
    users
  };
}
export default connect(mapStateToProps)(Login);